module.exports = function(socket, client) {
    console.log("socketController");

}
