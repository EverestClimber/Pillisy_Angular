#!/bin/bash
/bin/sleep 5 && /usr/bin/supervisor /home/devops/projects/Pillsy/PillsyEnterpriseWebApp/bin/www 2>&1