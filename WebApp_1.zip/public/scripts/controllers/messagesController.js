/** Pillsy
*  @author  Chuks Onwuneme
*  @version 1.0
*  @package MessagesController AngularJS module  
*/
   
var app = angular.module('MessagesController', []);  //instantiates MainController module
app.controller('MainController', function ($scope, $filter) {
  'use strict';

});
